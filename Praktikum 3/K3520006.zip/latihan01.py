Python 3.9.0 (tags/v3.9.0:9cf6752, Oct  5 2020, 15:34:40) [MSC v.1927 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> print("Hello world")
Hello world
>>> 
= RESTART: D:/Software/college/Python Project/Python-project-Protek/Praktikum 3/latihan02.py
Hello world
Hello world
Hello world
>>> 